from django.shortcuts import render, redirect
from .models import *

def index(request):
	context = {
	    'all_dates': Show.objects.all() 
	}
	return render(request,"allshows.html",context)

def createShowPage(request):
	return render(request, "create.html")

def createShow(request):
	print(request.POST)
	newshow = Show.objects.create(title = request.POST['name'], Network = request.POST['network'], Release= request.POST['release'], desc = request.POST['description'])
	print(newshow)

	return redirect(f"/shows/{newshow.id}")


def showInfo(request, show_id):
	showToshow = Show.objects.get(id= show_id)
	print(showToshow)
	context = {
		'tvshow': showToshow
	}
	return render(request, 'Read.html', context)



def editShow(request, show_id):
	showToEdit = Show.objects.get(id= show_id)
	print(showToEdit)
	context = {
		'editshow': showToEdit
	}

	return render(request, 'update.html', context)

def updateShow(request, show_id):
	print(request.POST)
	editShow = Show.objects.get(id= show_id)
	editShow.title = request.POST['nombre']
	editShow.Network = request.POST['net']
	editShow.Release = request.POST['rel']
	editShow.desc = request.POST['description']
	editShow.save()

	return redirect(f'/shows/{show_id}')

def delete(request, show_id):
	showtodelete = Show.objects.get(id= show_id)
	showtodelete.delete()
	return redirect('/shows')

	# context = {
	# 	'showToshow': Course.objects.get(id= show_id)
	# }
	# return render(request,'allshows.html', context)

# def process_edit(request, allshows_id):
# 	showToEdit = show.objects.get(id= allshows_id)
# 	context = {
# 		'editshow': showToEdit
# 	}

# 	return render(request, 'update.html')
