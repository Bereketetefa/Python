from django.urls import path, include 

urlpatterns = [
    path('', include('tv_app.urls')),
]