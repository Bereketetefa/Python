from django.apps import AppConfig


class LoginProjectAppConfig(AppConfig):
    name = 'login_project_app'
