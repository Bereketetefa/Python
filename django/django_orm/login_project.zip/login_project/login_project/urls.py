from django.urls import path, include 

urlpatterns = [
    path('', include('login_project_app.urls')),
]
