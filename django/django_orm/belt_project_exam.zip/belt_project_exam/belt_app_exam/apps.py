from django.apps import AppConfig


class BeltAppExamConfig(AppConfig):
    name = 'belt_app_exam'
