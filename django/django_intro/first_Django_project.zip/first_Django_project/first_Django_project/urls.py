from django.urls import path, include
urlpatterns = [
    path('', include('your_app_name_here.urls')),
]



# from django.urls import path, include          
# urlpatterns = [
#     path('', include('your_app_name_here.urls')),	   
# ]